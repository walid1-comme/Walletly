/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL: string;
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  readonly VITE_PAY_MONTHLY: string;
  readonly VITE_PAY_QUARTERLY: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
